PARA practice notes. Synthetic examples. Open in a separate practice vault. Dates are literal text; no automation or sync is configured.
